#include "volimage.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
	
int number_of_images = 0;

VolImage::VolImage(){
	VolImage::width = 0;
	VolImage::height = 0;
	VolImage::slices = vector<unsigned char**> (0);
}

VolImage::~VolImage(){
	VolImage::slices.~vector();
}

bool VolImage::readImages(string baseName){

	ifstream ifs(baseName + ".data");
	int data[3] = {};
	ostringstream oss;

	if(!ifs){
		cerr << "Unable to open " + baseName;
		exit(1);
	}

	for (int i = 0; i < 3; i++){
		ifs >> data[i];
	}

	VolImage::width = data[0];
	VolImage::height = data[1];
	number_of_images = data[2];

	VolImage::slices.resize(number_of_images);

	for (int i = 0; i < number_of_images; i++){
		VolImage::slices[i] = new u_char* [VolImage::height];
		oss << i;
		ifstream raws(baseName + oss.str() + ".raw", ios::binary);
		for(int j = 0; j < VolImage::height; j++){
			VolImage::slices[i][j] = new u_char [VolImage::width];
			for(int k = 0; k < VolImage::width; k++){
				VolImage::slices[i][j][k] = u_char(raws.get());
				oss.str("");
			}
		}
		raws.close();
	}


	return true;
}

void VolImage::diffmap(int sliceI, int sliceJ, string output_prefix){

	ofstream ofs(output_prefix + ".raw", ios::binary);
	vector<unsigned char**> volume = vector<unsigned char**> (2);

	for (int i = 0; i < number_of_images; i++){
		if(sliceI == i){
			volume[0] = VolImage::slices[i];
		}
		else if(sliceJ == i){
			volume[1] = VolImage::slices[i];
		}
	}

		for (int j = 0; j < VolImage::height; j++){
			for(int k = 0; k < VolImage::width; k++){
				ofs << (u_char)(abs((float)volume[0][j][k] - (float)volume[1][j][k])/2);
			}
		}
}

void VolImage::extract(int sliceId, string output_prefix){
	
	ofstream ofs(output_prefix + ".raw", ios::binary);

	for (int i = 0; i < number_of_images; i++){
		if (sliceId == i){
			for (int j = 0; j < VolImage::height; j++){
				for(int k = 0; k < VolImage::width; k++){
					ofs << VolImage::slices[i][j][k];
				}
			}
		}
	}

	ofs.close();

	ofstream ofs1(output_prefix + ".data");
	ofs1 << VolImage::width << " " << VolImage::height << " " << number_of_images;
	ofs1.close();

}

void VolImage::volImageSize(void){
	int slicesSize = sizeof(slices);
	cout << slicesSize << endl;
}

void VolImage::volumetric(int rowI, string output_prefix){

	ofstream ofs(output_prefix + ".raw", ios::binary);

	for (int i = 0; i < number_of_images; i++){
		for (int j = 0; j < VolImage::width; j++){
			ofs << VolImage::slices[i][rowI][j];
		}
	}

	ofs.close();

	ofstream ofs1(output_prefix + ".data");

	ofs1 << VolImage::width << " " << number_of_images << " " << number_of_images;

	ofs1.close();
}

int main(int argc, char* argv[]) throw(){
	
	VolImage volImage;
	
	volImage.readImages(argv[1]);
	
	if(argv[2][1] == 'd'){
		volImage.diffmap(atoi(argv[3]), atoi(argv[4]), argv[5]);
	}
	else if(argv[2][1] == 'x'){
		volImage.extract(atoi(argv[3]), argv[4]);
	}
	else if(argv[2][1] == 'g'){
		volImage.volumetric(atoi(argv[3]), argv[4]);
	}
	else{
		cout << "unexpected input" << endl;
		return 1;
	}

	return 0;
}