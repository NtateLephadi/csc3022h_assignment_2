#include <vector>
#include <string>

using namespace std;

#ifndef VOLIMAGE_H_
#define VOLIMAGE_H_

class VolImage{

private: //private members

	int width, height; // width and height of stack
	vector<unsigned char**> slices; // data for ech slice, in order

public: // public members

	VolImage(); // default constructor - define in .cpp
	~VolImage(); // destructor - define in .cpp 

	/*
	* populate the object with images in stack
	* set member variables - define in .cpp
	*/
	bool readImages(string baseName);

	/*
	* compute difference map and write out - define in .cpp 
	*/
	void diffmap(int sliceI, int sliceJ, string output_prefix);

	/*
	* extract slice sliceId and write to output - define in .cpp
	*/
	void extract(int sliceId, string output_prefix);

	/*
	* number of bytes used to store image data bytes
	* and pointers (ignore vector<> container, dims etc) - define in .cpp
	*/
	void volImageSize(void);

	/*	
	* a new operation [-g i], which extracts an image along row i of the volume, 
	* across all slices and write out - define in .cpp
	*/
	void volumetric(int rowI, string output_prefix);

};

#endif